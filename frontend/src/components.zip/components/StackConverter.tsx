import React, { useState } from 'react';
import { ArrowRight, Code, Zap, Copy, RefreshCw, FileCode } from 'lucide-react';
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css';
import { useDropzone } from 'react-dropzone';

interface StackOption {
  value: string;
  label: string;
  icon: string;
}

interface PropInfo {
  name: string;
  defaultValue?: string;
}

const StackConverter: React.FC = () => {
  const [sourceCode, setSourceCode] = useState<string>(`import React, { useState } from 'react';

const Counter = ({ initialValue = 0 }) => {
  const [count, setCount] = useState(initialValue);
  
  const increment = () => {
    setCount(count + 1);
  };
  
  const decrement = () => {
    setCount(count - 1);
  };
  
  return (
    <div className="counter">
      <h2>Counter: {count}</h2>
      <button onClick={increment}>+</button>
      <button onClick={decrement}>-</button>
    </div>
  );
};

export default Counter;`);

  const [convertedCode, setConvertedCode] = useState<string>('');
  const [isConverting, setIsConverting] = useState<boolean>(false);
  const [sourceStack, setSourceStack] = useState<string>('react');
  const [targetStack, setTargetStack] = useState<string>('vue');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);

  const stackOptions: StackOption[] = [
    { value: 'react', label: 'React', icon: '⚛️' },
    { value: 'vue', label: 'Vue.js', icon: '🟢' },
    { value: 'angular', label: 'Angular', icon: '🔺' },
    { value: 'svelte', label: 'Svelte', icon: '🧡' }
  ];

  const onDrop = (acceptedFiles: File[]) => {
    if (acceptedFiles && acceptedFiles.length > 0) {
      setUploadedFile(acceptedFiles[0]);
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'application/zip': ['.zip'] },
    multiple: false,
    maxFiles: 1,
  });

  const convertReactToVue = (reactCode: string): string => {
    let vueCode = reactCode;
    
    if (reactCode.includes('useState')) {
      vueCode = convertFunctionalComponent(reactCode);
    } else if (reactCode.includes('class') && reactCode.includes('extends')) {
      vueCode = convertClassComponent(reactCode);
    } else {
      vueCode = convertSimpleComponent(reactCode);
    }
    
    return vueCode;
  };

  const convertFunctionalComponent = (reactCode: string): string => {
    const componentMatch = reactCode.match(/(?:const|function)\s+(\w+)/);
    const componentName = componentMatch ? componentMatch[1] : 'ConvertedComponent';
    
    const propsMatch = reactCode.match(/\(\s*\{([^}]*)\}\s*\)/);
    const propsStr = propsMatch ? propsMatch[1] : '';
    const propsArray: PropInfo[] = propsStr.split(',').map(p => {
      const [name, defaultValue] = p.trim().split('=').map(s => s.trim());
      return { name, defaultValue };
    }).filter(p => p.name);
    
    const stateMatches = [...reactCode.matchAll(/const\s+\[(\w+),\s*set\w+\]\s*=\s*useState\(([^)]*)\);/g)];
    
    const template = extractJSXTemplate(reactCode);
    const dataProperties = stateMatches.map(match => `      ${match[1]}: ${match[2] || 'null'}`).join(',\n');
    
    return `<template>
${template}
</template>

<script>
export default {
  name: '${componentName}',
  props: {${propsArray.map(prop => `
    ${prop.name}: {
      type: [String, Number, Boolean, Object, Array],
      default: ${prop.defaultValue || 'undefined'}
    }`).join(',')}
  },
  data() {
    return {
${dataProperties}
    };
  },
  methods: {
${extractMethods(reactCode)}
  }
};
</script>`;
  };

  const convertClassComponent = (reactCode: string): string => {
    const componentMatch = reactCode.match(/class\s+(\w+)/);
    const componentName = componentMatch ? componentMatch[1] : 'ConvertedComponent';
    
    return `<template>
  <div class="converted-component">
    <h3>{{ title }}</h3>
    <p>Class component conversion coming soon!</p>
  </div>
</template>

<script>
export default {
  name: '${componentName}',
  data() {
    return {
      title: 'Class Component Converted'
    };
  }
};
</script>`;
  };

  const convertSimpleComponent = (reactCode: string): string => {
    return `<template>
  <div class="simple-component">
    <h3>Simple Component</h3>
    <p>Basic conversion applied</p>
  </div>
</template>

<script>
export default {
  name: 'SimpleComponent'
};
</script>`;
  };

  const extractJSXTemplate = (reactCode: string): string => {
    const returnMatch = reactCode.match(/return\s*\(([^]*?)\);/);
    if (!returnMatch) return '  <div>No template found</div>';
    
    let jsx = returnMatch[1].trim();
    
    jsx = jsx.replace(/className=/g, 'class=');
    jsx = jsx.replace(/onClick=/g, '@click=');
    jsx = jsx.replace(/\{([^}]+)\}/g, '{{ $1 }}');
    jsx = jsx.replace(/{{(\s*\w+\s*)}}/g, '{{ $1 }}');
    
    return jsx.split('\n').map(line => '  ' + line).join('\n');
  };

  const extractMethods = (reactCode: string): string => {
    const methodMatches = [...reactCode.matchAll(/const\s+(\w+)\s*=\s*\([^)]*\)\s*=>\s*\{([^}]*)\};?/g)];
    
    return methodMatches.map(match => {
      const methodName = match[1];
      let methodBody = match[2];
      
      methodBody = methodBody.replace(/set(\w+)\(([^)]*)\)/g, (setMatch, stateName, value) => {
        const lowerStateName = stateName.charAt(0).toLowerCase() + stateName.slice(1);
        return `this.${lowerStateName} = ${value}`;
      });
      
      return `    ${methodName}() {${methodBody}
    }`;
    }).join(',\n');
  };

  const convertCode = async (): Promise<void> => {
    setIsConverting(true);
    setConvertedCode('');
    try {
      const response = await fetch('/convert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sourceCode,
          sourceStack,
          targetStack,
        }),
      });
      const data = await response.json();
      setConvertedCode(data.convertedCode || '// Conversion failed or no result.');
    } catch (error) {
      setConvertedCode('// Error connecting to backend.');
    }
    setIsConverting(false);
  };

  const copyToClipboard = async (text: string): Promise<void> => {
    try {
      await navigator.clipboard.writeText(text);
    } catch (err) {
      console.error('Failed to copy text');
    }
  };

  const resetCode = (): void => {
    setSourceCode(`import React, { useState } from 'react';

const Counter = ({ initialValue = 0 }) => {
  const [count, setCount] = useState(initialValue);
  
  const increment = () => {
    setCount(count + 1);
  };
  
  const decrement = () => {
    setCount(count - 1);
  };
  
  return (
    <div className="counter">
      <h2>Counter: {count}</h2>
      <button onClick={increment}>+</button>
      <button onClick={decrement}>-</button>
    </div>
  );
};

export default Counter;`);
    setConvertedCode('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-3 mr-4">
              <Zap className="h-8 w-8 text-yellow-400" />
            </div>
            <h1 className="text-4xl font-bold text-white">StackConverter</h1>
          </div>
          <p className="text-gray-300 text-lg">Transform your entire codebase between different tech stacks</p>
          <div className="mt-2 px-4 py-2 bg-blue-500/20 rounded-full text-blue-300 text-sm inline-block">
            🚀 Prototype Demo - React to Vue Conversion
          </div>
        </div>

        {/* File Upload Area */}
        <div className="mb-8">
          <div
            {...getRootProps()}
            className={
              'border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-colors ' +
              (isDragActive
                ? 'border-blue-400 bg-blue-900/20'
                : 'border-gray-600 bg-gray-800/30 hover:border-blue-400')
            }
          >
            <input {...getInputProps()} />
            {uploadedFile ? (
              <div className="text-white">
                <strong>Selected file:</strong> {uploadedFile.name} ({(uploadedFile.size / 1024).toFixed(1)} KB)
              </div>
            ) : (
              <div className="text-gray-300">
                Drag & drop a <span className="font-bold">.zip</span> file here, or click to select one
              </div>
            )}
          </div>
        </div>

        {/* Stack Selection */}
        <div className="flex items-center justify-center mb-8 space-x-4">
          <div className="relative">
            <select 
              value={sourceStack} 
              onChange={(e) => setSourceStack(e.target.value)}
              className="appearance-none bg-gray-800/50 backdrop-blur-sm border border-gray-600 rounded-xl px-6 py-3 text-white text-lg font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-12"
            >
              {stackOptions.map(option => (
                <option key={option.value} value={option.value}>
                  {option.icon} {option.label}
                </option>
              ))}
            </select>
            <FileCode className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400 pointer-events-none" />
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-full p-3">
            <ArrowRight className="h-6 w-6 text-white" />
          </div>
          
          <div className="relative">
            <select 
              value={targetStack} 
              onChange={(e) => setTargetStack(e.target.value)}
              className="appearance-none bg-gray-800/50 backdrop-blur-sm border border-gray-600 rounded-xl px-6 py-3 text-white text-lg font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-12"
            >
              {stackOptions.map(option => (
                <option key={option.value} value={option.value}>
                  {option.icon} {option.label}
                </option>
              ))}
            </select>
            <FileCode className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400 pointer-events-none" />
          </div>
        </div>

        {/* Convert Button */}
        <div className="flex justify-center mb-8">
          <button 
            onClick={convertCode}
            disabled={isConverting}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 disabled:from-gray-500 disabled:to-gray-600 text-white font-bold py-4 px-8 rounded-2xl text-lg transition-all duration-200 transform hover:scale-105 disabled:scale-100 shadow-lg flex items-center space-x-2"
          >
            {isConverting ? (
              <>
                <RefreshCw className="h-5 w-5 animate-spin" />
                <span>Converting...</span>
              </>
            ) : (
              <>
                <Code className="h-5 w-5" />
                <span>Convert Stack</span>
              </>
            )}
          </button>
        </div>

        {/* Code Areas */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Source Code */}
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl overflow-hidden border border-gray-700">
            <div className="bg-gray-700/50 px-6 py-4 border-b border-gray-600 flex items-center justify-between">
              <h3 className="text-white font-semibold text-lg">
                Source Code ({stackOptions.find(s => s.value === sourceStack)?.icon} {stackOptions.find(s => s.value === sourceStack)?.label})
              </h3>
              <button 
                onClick={resetCode}
                className="text-gray-400 hover:text-white transition-colors"
                title="Reset to example"
              >
                <RefreshCw className="h-4 w-4" />
              </button>
            </div>
            <textarea
              value={sourceCode}
              onChange={(e) => setSourceCode(e.target.value)}
              className="w-full h-80 bg-transparent text-gray-100 font-mono text-sm p-6 resize-none focus:outline-none placeholder-gray-400"
              placeholder="Paste your source code here..."
              style={{ fontFamily: 'Fira Code, Monaco, Consolas, monospace' }}
            />
          </div>

          {/* Converted Code */}
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl overflow-hidden border border-gray-700">
            <div className="bg-gray-700/50 px-6 py-4 border-b border-gray-600 flex items-center justify-between">
              <h3 className="text-white font-semibold text-lg">
                Converted Code ({stackOptions.find(s => s.value === targetStack)?.icon} {stackOptions.find(s => s.value === targetStack)?.label})
              </h3>
              {convertedCode && !isConverting && (
                <button 
                  onClick={() => copyToClipboard(convertedCode)}
                  className="text-gray-400 hover:text-white transition-colors"
                  title="Copy to clipboard"
                >
                  <Copy className="h-4 w-4" />
                </button>
              )}
            </div>
            <div className="relative">
              {isConverting ? (
                <div className="p-6 bg-gray-800/30 backdrop-blur-sm rounded-2xl">
                  <Skeleton
                    count={16}
                    height={18}
                    style={{ marginBottom: 6, borderRadius: 3 }}
                    baseColor="rgba(30,41,59,0.6)"
                    highlightColor="rgba(59,130,246,0.15)"
                  />
                </div>
              ) : (
                <>
                  <textarea
                    value={convertedCode}
                    readOnly
                    className="w-full h-80 bg-transparent text-gray-100 font-mono text-sm p-6 resize-none focus:outline-none"
                    placeholder="Converted code will appear here..."
                    style={{ fontFamily: 'Fira Code, Monaco, Consolas, monospace' }}
                  />
                  {!convertedCode && (
                    <div className="absolute inset-0 flex items-center justify-center text-gray-500 pointer-events-none">
                      <div className="text-center">
                        <Code className="h-12 w-12 mx-auto mb-2 opacity-50" />
                        <p>Run conversion to see results</p>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>

        {/* Features */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
            <div className="text-blue-400 text-2xl mb-4">🔄</div>
            <h3 className="text-white font-semibold mb-2">Smart Conversion</h3>
            <p className="text-gray-300 text-sm">AI-powered analysis converts components, state management, and lifecycle methods intelligently.</p>
          </div>
          
          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
            <div className="text-green-400 text-2xl mb-4">⚡</div>
            <h3 className="text-white font-semibold mb-2">Full Stack Support</h3>
            <p className="text-gray-300 text-sm">Convert entire projects including build configs, routing, state management, and testing.</p>
          </div>
          
          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
            <div className="text-purple-400 text-2xl mb-4">🎯</div>
            <h3 className="text-white font-semibold mb-2">Best Practices</h3>
            <p className="text-gray-300 text-sm">Generated code follows framework conventions and modern best practices out of the box.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StackConverter; 